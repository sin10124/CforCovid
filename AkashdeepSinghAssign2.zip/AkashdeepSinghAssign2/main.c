
/***********************
*  Name: Akashdeep Singh
*  Student ID: 991586783
*  Date of coding: June 29, 2021
*  Assignment 2
***********************/

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include "household.h"

int main() {
    int stop = 0;

    int i=0;
    while(stop!=9 && i != 3)
    {
        printf("Provide data of up to three households! Press any number to proceed or enter 9 to skip manual data entry and to generate records randomly\n");
        scanf("%d",&stop);

        if(stop == 9)
        {
            break;
        }

        printf("Data entry for household #%d\n",(i+1));

        int raceChoice;
        printf("race: enter an integer: Indigenous(0), Caucasian(1), African American(2), Asian(3), Others(4)\n");
        scanf("%d", &raceChoice);
        strcpy(households[i].raceOfHeadOfHousehold, raceNames[raceChoice]);

        printf("region: enter an integer: Durham(0), Peel(1), York(2)\n");
        int regionChoice;
        scanf("%d", &regionChoice);
        strcpy(households[i].region,regionNames[regionChoice]);
        while(1)
        {
            int townChoice;
            switch (regionChoice)
            {
                case 0:
                    printf("town: enter an integer: Whitby(0), Oshawa(1)\n");
                    scanf("%d", &townChoice);
                    strcpy(households[i].town,townForDurham[townChoice]);
                    break;
                case 1:
                    printf("town: enter an integer: Brampton(0), Mississauga(1)\n");
                    scanf("%d", &townChoice);
                    strcpy(households[i].town,townForPeel[townChoice]);
                    break;
                case 2:
                    printf("town: enter an integer: Maple(0), Vaughan(1)\n");
                    scanf("%d", &townChoice);
                    strcpy(households[i].town,townForYork[townChoice]);
                    break;
                default:
                    printf("Please pick valid options only!\n");
            }
            if(strlen(households[i].town) > 1)
            {
                break;
            }
        }

        int yearlyIncome;
        do
        {
            printf("Enter annual household income: enter an integer:\n");
            scanf("%d", &yearlyIncome);
            if(yearlyIncome < 0)
            {
                printf("Enter positive number only!\n");
            }
        }while(yearlyIncome < 0);
        households[i].yearlyIncome = yearlyIncome;

        int ctr = -1;
        char input[100];
        int numberOfPeople, membersTested, membersTestedPositive;
        printf("Enter number of household members, members tested for Covid-19 and members tested positive for Covid-19 respectively as\nthree integers separated by space or tab");
        while(1)
        {
            fgets(input, sizeof(input), stdin);
            ctr = sscanf(input, "%d%d%d", &numberOfPeople, &membersTested, &membersTestedPositive);
            if(ctr != 3)
            {
                printf("Enter three positive numbers!\n");
                continue;
            }

            if(!(numberOfPeople >= membersTested && numberOfPeople >= membersTestedPositive && membersTested >= membersTestedPositive))
            {
                printf("Enter valid data!\n");
                continue;
            }
            break;
        }

        households[i].numberOfPeople = numberOfPeople;
        households[i].membersTested = membersTested;
        households[i].membersTestedPositive = membersTestedPositive;

        i++;
    }

    printf("Generate random entries!\n");
    households[SIZE] = generateRandomHouseholds(households, i);
    printHouseholds();
    printMainMenu();

    return 0;
}

Household generateRandomHouseholds(Household households[SIZE], int start)
{
    srand(time(0));
    for(int i=start; i<SIZE; i++)
    {
        strcpy(households[i].raceOfHeadOfHousehold, raceNames[rand() % 5]);

        int regionChoice = rand()%3;
        strcpy(households[i].region, regionNames[regionChoice]);
        switch (regionChoice)
        {
            case 0:
                strcpy(households[i].town,townForDurham[rand()%2]);
                break;
            case 1:
                strcpy(households[i].town,townForPeel[rand()%2]);
                break;
            case 2:
                strcpy(households[i].town,townForYork[rand()%2]);
                break;
        }

        households[i].yearlyIncome = rand()%500000 + 20000;

        households[i].numberOfPeople = rand()%50 + 1;
        do
        {
            households[i].membersTested = rand()%50 + 1;

            households[i].membersTestedPositive = rand()%50 + 1;
        } while (!(households[i].numberOfPeople >= households[i].membersTested && households[i].numberOfPeople >= households[i].membersTestedPositive && households[i].membersTested >= households[i].membersTestedPositive));
    }

    return households[SIZE];
}

void printHouseholds()
{
    printf("%4s%22s%12s%15s%10s%15s%14s%16s\n","S.no","Race","Region","Town","Income","Family Size","Covid Tested","Covid Positive");
    for(int i=0; i<SIZE; i++)
    {
        printf("%4d%22s%12s%15s%10d%15d%14d%16d\n", i+1, households[i].raceOfHeadOfHousehold, households[i].region, households[i].town, households[i].yearlyIncome, households[i].numberOfPeople, households[i].membersTested, households[i].membersTestedPositive);
    }
}

void printMainMenu()
{
    int choice = -1;
    while(choice != 0)
    {
        printf("Main Menu:\n");
        printf("Enter your choice to display\n1. Household records by race, region, or town\n2. Races ranking for Covid-19\n3. Regions ranking for Covid-19\n4. Towns ranking for Covid-19\n5. Races ranking by poverty\n0. Exit\n");

        scanf("%d",&choice);
        switch (choice)
        {
            case 1:
                printSubMenuForRaceTownAndRegion();
                break;
            case 2:
                printSubMenuForRaceRanking();
                break;
            case 3:
                printSubMenuForRegionRanking();
                break;
            case 4:
                printSubMenuForTownRanking();
                break;
            case 5:
                printRaceRankingByPoverty();
                break;
            case 0:
                break;
            default:
                printf("Enter valid options only!\n");
        }
    }
}

void printSubMenuForRaceTownAndRegion()
{
    printf("Enter an integer to see household records of a particular race (0), region (1), or town (2)\n");
    int choice;
    scanf("%d", &choice);
    switch (choice)
    {
        case 0:
            printHouseholdsByRace();
            break;
        case 1:
            printHouseholdsByRegion();
            break;
        case 2:
            printHouseholdsByTown();
            break;
        default:
            printf("Enter valid options only!\n");
    }

}

void printHouseholdsByRace()
{
    printf("Enter an integer: Indigenous (0), Caucasian (1), African American (2), Asian (3), or Others (4)\n");
    int choice;
    scanf("%d", &choice);
    if(choice == 0 || choice == 1 || choice == 2 || choice == 3 || choice == 4)
    {
        printf("%4s%22s%12s%15s%10s%15s%14s%16s\n","S.no","Race","Region","Town","Income","Family Size","Covid Tested","Covid Positive");
        int count = 0;
        for(int i=0; i<SIZE; i++)
        {
            if(strcmp(households[i].raceOfHeadOfHousehold,raceNames[choice]) == 0)
            {
                count++;
                printf("%4d%22s%12s%15s%10d%15d%14d%16d\n", count, households[i].raceOfHeadOfHousehold, households[i].region, households[i].town, households[i].yearlyIncome, households[i].numberOfPeople, households[i].membersTested, households[i].membersTestedPositive);
            }
        }
    }
    else
    {
        printf("Enter valid options only!\n");
    }
}

void printHouseholdsByTown()
{
    printf("Enter an integer:  Your region - Durham (0), Peel (1), or York (2)\n");
    int region;
    scanf("%d", &region);
    int town;
    char towns[50];

    switch (region)
    {
        case 0:
            printf("Enter an integer: Your town - Whitby (0) or Oshawa (1)\n");
            scanf("%d", &town);
            strcpy(towns, townForDurham[town]);
            break;
        case 1:
            printf("Enter an integer: Your town - Brampton (0) or Mississauga (1)\n");
            scanf("%d", &town);
            strcpy(towns, townForPeel[town]);
            break;
        case 2:
            printf("Enter an integer: Your town - Maple (0) or Vaughan (1)\n");
            scanf("%d", &town);
            strcpy(towns, townForYork[town]);
            break;
        default:
            printf("Enter valid options only!\n");
            break;
    }

    printf("%4s%22s%12s%15s%10s%15s%14s%16s\n","S.no","Race","Region","Town","Income","Family Size","Covid Tested","Covid Positive");
    int count = 0;
    for(int i=0; i<SIZE; i++)
    {
        if(strcmp(households[i].town, towns) == 0)
        {
            count++;
            printf("%4d%22s%12s%15s%10d%15d%14d%16d\n", count, households[i].raceOfHeadOfHousehold, households[i].region, households[i].town, households[i].yearlyIncome, households[i].numberOfPeople, households[i].membersTested, households[i].membersTestedPositive);
        }
    }
}

void printHouseholdsByRegion()
{
    printf("Enter an integer: Durham (0), Peel (1), or York (2)\n");
    int choice;
    scanf("%d", &choice);
    if(choice == 0 || choice == 1 || choice == 2)
    {
        printf("%4s%22s%12s%15s%10s%15s%14s%16s\n","S.no","Race","Region","Town","Income","Family Size","Covid Tested","Covid Positive");
        int j=0;
        for(int i=0; i<SIZE; i++)
        {

            if(strcmp(households[i].region,regionNames[choice]) == 0)
            {
                j++;
                printf("%4d%22s%12s%15s%10d%15d%14d%16d\n", j, households[i].raceOfHeadOfHousehold, households[i].region, households[i].town, households[i].yearlyIncome, households[i].numberOfPeople, households[i].membersTested, households[i].membersTestedPositive);
            }
        }
    }
    else
    {
        printf("Enter valid options only!\n");
    }
}

void printSubMenuForRaceRanking()
{
    printf("Enter 0 to see all covid-19 cases tested or\n1 for only tested positive cases or\n9 to go back to the main menu\n");
    int choice;
    scanf("%d", &choice);
    switch (choice)
    {
        case 0:
            printRaceRankingOfCovidTested();
            break;
        case 1:
            printRaceRankingOfCovidTestedPositive();
            break;
        case 9:
            break;
        default:
            printf("Enter valid options only!\n");
            break;
    }
}

void printRaceRankingOfCovidTested()
{
    int africanAmericanCovidTestedCases = 0;
    int asianCovidTestedCases = 0;
    int indigenousCovidTestedCases = 0;
    int caucasianCovidTestedCases = 0;
    int othersCovidTestedCases = 0;

    for(int i=0; i<SIZE; i++)
    {
        if(strcmp(households[i].raceOfHeadOfHousehold, raceNames[0]) == 0)
        {
            indigenousCovidTestedCases += households[i].membersTested;
        }
        else if(strcmp(households[i].raceOfHeadOfHousehold, raceNames[1]) == 0)
        {
            caucasianCovidTestedCases += households[i].membersTested;
        }
        else if(strcmp(households[i].raceOfHeadOfHousehold, raceNames[2]) == 0)
        {
            africanAmericanCovidTestedCases += households[i].membersTested;
        }
        else if(strcmp(households[i].raceOfHeadOfHousehold, raceNames[3]) == 0)
        {
            asianCovidTestedCases += households[i].membersTested;
        }
        else
        {
            othersCovidTestedCases += households[i].membersTested;
        }
    }

    RaceRankingByCovid raceRankingByCovid[5];

    strcpy(raceRankingByCovid[0].race, raceNames[0]);
    raceRankingByCovid[0].membersTested = indigenousCovidTestedCases;

    strcpy(raceRankingByCovid[1].race, raceNames[1]);
    raceRankingByCovid[1].membersTested = caucasianCovidTestedCases;

    strcpy(raceRankingByCovid[2].race, raceNames[2]);
    raceRankingByCovid[2].membersTested = africanAmericanCovidTestedCases;

    strcpy(raceRankingByCovid[3].race, raceNames[3]);
    raceRankingByCovid[3].membersTested = asianCovidTestedCases;

    strcpy(raceRankingByCovid[4].race, raceNames[4]);
    raceRankingByCovid[4].membersTested = othersCovidTestedCases;

    printf("%22s%14s\n","Races:","Covid Tested");
    for (int i = 0; i < 5; i++)
    {
        printf("%22s:%14d\n", raceRankingByCovid[i].race, raceRankingByCovid[i].membersTested);
    }
}

void printRaceRankingOfCovidTestedPositive()
{
    int africanAmericanPositiveCovidTestedCases = 0;
    int asianPositiveCovidTestedCases = 0;
    int indigenousPositiveCovidTestedCases = 0;
    int caucasianPositiveCovidTestedCases = 0;
    int othersPositiveCovidTestedCases = 0;

    for(int i=0; i<SIZE; i++)
    {
        if(strcmp(households[i].raceOfHeadOfHousehold, raceNames[0]) == 0)
        {
            indigenousPositiveCovidTestedCases += households[i].membersTestedPositive;
        }
        else if(strcmp(households[i].raceOfHeadOfHousehold, raceNames[1]) == 0)
        {
            caucasianPositiveCovidTestedCases += households[i].membersTestedPositive;
        }
        else if(strcmp(households[i].raceOfHeadOfHousehold, raceNames[2]) == 0)
        {
            africanAmericanPositiveCovidTestedCases += households[i].membersTestedPositive;
        }
        else if(strcmp(households[i].raceOfHeadOfHousehold, raceNames[3]) == 0)
        {
            asianPositiveCovidTestedCases += households[i].membersTestedPositive;
        }
        else
        {
            othersPositiveCovidTestedCases += households[i].membersTestedPositive;
        }
    }

    RaceRankingByCovidPositive raceRankingByCovidPositive[5];

    strcpy(raceRankingByCovidPositive[0].race, raceNames[0]);
    raceRankingByCovidPositive[0].membersTestedPositive = indigenousPositiveCovidTestedCases;

    strcpy(raceRankingByCovidPositive[1].race, raceNames[1]);
    raceRankingByCovidPositive[1].membersTestedPositive = caucasianPositiveCovidTestedCases;

    strcpy(raceRankingByCovidPositive[2].race, raceNames[2]);
    raceRankingByCovidPositive[2].membersTestedPositive = africanAmericanPositiveCovidTestedCases;

    strcpy(raceRankingByCovidPositive[3].race, raceNames[3]);
    raceRankingByCovidPositive[3].membersTestedPositive = asianPositiveCovidTestedCases;

    strcpy(raceRankingByCovidPositive[4].race, raceNames[4]);
    raceRankingByCovidPositive[4].membersTestedPositive = othersPositiveCovidTestedCases;

    printf("%22s:%16s\n","Races","Covid Positive");
    for (int i = 0; i < 5; i++)
    {
        printf("%22s:%16d\n", raceRankingByCovidPositive[i].race, raceRankingByCovidPositive[i].membersTestedPositive);
    }
}

void printSubMenuForRegionRanking()
{
    printf("Enter 0 to see all covid-19 cases tested or\n1 for only tested positive cases or\n9 to go back to the main menu\n");
    int choice;
    scanf("%d", &choice);
    switch (choice)
    {
        case 0:
            printRegionRankingOfCovidTested();
            break;
        case 1:
            printRegionRankingOfCovidTestedPositive();
            break;
        case 9:
            break;
        default:
            printf("Enter valid options only!\n");
            break;
    }
}

void printRegionRankingOfCovidTested()
{
    {
        int durhamCovidTestedCases = 0;
        int peelCovidTestedCases = 0;
        int yorkCovidTestedCases = 0;

        for(int i=0; i<SIZE; i++)
        {
            if(strcmp(households[i].region, regionNames[0]) == 0)
            {
                durhamCovidTestedCases += households[i].membersTested;
            }
            else if(strcmp(households[i].region, regionNames[1]) == 0)
            {
                peelCovidTestedCases += households[i].membersTested;
            }
            else if(strcmp(households[i].region, regionNames[2]) == 0)
            {
                yorkCovidTestedCases += households[i].membersTested;
            }
        }

        RegionRankingByCovid regionRankingByCovid[3];

        strcpy(regionRankingByCovid[0].region, regionNames[0]);
        regionRankingByCovid[0].membersTested = durhamCovidTestedCases;

        strcpy(regionRankingByCovid[1].region, regionNames[1]);
        regionRankingByCovid[1].membersTested = peelCovidTestedCases;

        strcpy(regionRankingByCovid[2].region, regionNames[2]);
        regionRankingByCovid[2].membersTested = yorkCovidTestedCases;


        printf("%14s:%14s\n","Regions","Covid Tested");
        for (int i = 0; i < 3; i++)
        {
            printf("%14s:%14d\n", regionRankingByCovid[i].region, regionRankingByCovid[i].membersTested);
        }
    }
}

void printRegionRankingOfCovidTestedPositive()
{
    {
        int durhamPositiveCovidTestedCases = 0;
        int peelPositiveCovidTestedCases = 0;
        int yorkPositiveCovidTestedCases = 0;

        for(int i=0; i<SIZE; i++)
        {
            if(strcmp(households[i].region, regionNames[0]) == 0)
            {
                durhamPositiveCovidTestedCases += households[i].membersTestedPositive;
            }
            else if(strcmp(households[i].region, regionNames[1]) == 0)
            {
                peelPositiveCovidTestedCases += households[i].membersTestedPositive;
            }
            else if(strcmp(households[i].region, regionNames[2]) == 0)
            {
                yorkPositiveCovidTestedCases += households[i].membersTestedPositive;
            }
        }

        RegionRankingByCovidPositive regionRankingByCovidPositive[3];

        strcpy(regionRankingByCovidPositive[0].region, regionNames[0]);
        regionRankingByCovidPositive[0].membersTestedPositive = durhamPositiveCovidTestedCases;

        strcpy(regionRankingByCovidPositive[1].region, regionNames[1]);
        regionRankingByCovidPositive[1].membersTestedPositive = peelPositiveCovidTestedCases;

        strcpy(regionRankingByCovidPositive[2].region, regionNames[2]);
        regionRankingByCovidPositive[2].membersTestedPositive = yorkPositiveCovidTestedCases;

        printf("%14s:%16s\n","Races:","Covid Positive");
        for (int i = 0; i < 3; i++)
        {
            printf("%14s:%16d\n", regionRankingByCovidPositive[i].region, regionRankingByCovidPositive[i].membersTestedPositive);
        }
    }
}

void printSubMenuForTownRanking()
{
    printf("Enter 0 to see all covid-19 cases tested or\n1 for only tested positive cases or\n9 to go back to the main menu\n");
    int choice;
    scanf("%d", &choice);
    switch (choice)
    {
        case 0:
            printTownRankingOfCovidTested();
            break;
        case 1:
            printTownRankingOfCovidTestedPositive();
            break;
        case 9:
            break;
        default:
            printf("Enter valid options only!\n");
            break;
    }
}

void printTownRankingOfCovidTested()
{
    {
        int bramptonCovidTestedCases = 0;
        int mississaugaCovidTestedCases = 0;
        int mapleCovidTestedCases = 0;
        int vaughanCovidTestedCases = 0;
        int whitbyCovidTestedCases = 0;
        int oshawaCovidTestedCases = 0;

        char townNames[6][30] = {"Brampton", "Mississauga", "Maple", "Vaughan", "Whitby", "Oshawa"};

        for(int i=0; i<SIZE; i++)
        {
            if(strcmp(households[i].town, townNames[0]) == 0)
            {
                bramptonCovidTestedCases += households[i].membersTested;
            }
            else if(strcmp(households[i].town, townNames[1]) == 0)
            {
                mississaugaCovidTestedCases += households[i].membersTested;
            }
            else if(strcmp(households[i].town, townNames[2]) == 0)
            {
                mapleCovidTestedCases += households[i].membersTested;
            }
            else if(strcmp(households[i].town, townNames[3]) == 0)
            {
                vaughanCovidTestedCases += households[i].membersTested;
            }
            else if(strcmp(households[i].town, townNames[4]) == 0)
            {
                whitbyCovidTestedCases += households[i].membersTested;
            }
            else if(strcmp(households[i].town, townNames[5]) == 0)
            {
                oshawaCovidTestedCases += households[i].membersTested;
            }
        }

        TownRankingByCovid townRankingByCovid[6];

        strcpy(townRankingByCovid[0].town, townNames[0]);
        townRankingByCovid[0].membersTested = bramptonCovidTestedCases;

        strcpy(townRankingByCovid[1].town, townNames[1]);
        townRankingByCovid[1].membersTested = mississaugaCovidTestedCases;

        strcpy(townRankingByCovid[2].town, townNames[2]);
        townRankingByCovid[2].membersTested = mapleCovidTestedCases;

        strcpy(townRankingByCovid[3].town, townNames[3]);
        townRankingByCovid[3].membersTested = vaughanCovidTestedCases;

        strcpy(townRankingByCovid[4].town, townNames[4]);
        townRankingByCovid[4].membersTested = whitbyCovidTestedCases;

        strcpy(townRankingByCovid[5].town, townNames[5]);
        townRankingByCovid[5].membersTested = oshawaCovidTestedCases;

        printf("%16s:%14s\n","Town","Covid Tested");
        for (int i = 0; i < 6; i++)
        {
            printf("%16s:%14d\n", townRankingByCovid[i].town, townRankingByCovid[i].membersTested);
        }
    }
}

void printTownRankingOfCovidTestedPositive()
{
    {
        int bramptonPositiveCovidTestedCases = 0;
        int mississaugaPositiveCovidTestedCases = 0;
        int maplePositiveCovidTestedCases = 0;
        int vaughanPositiveCovidTestedCases = 0;
        int whitbyPositiveCovidTestedCases = 0;
        int oshawaPositiveCovidTestedCases = 0;

        char townNames[6][30] = {"Brampton", "Mississauga", "Maple", "Vaughan", "Whitby", "Oshawa"};

        for(int i=0; i<SIZE; i++)
        {
            if(strcmp(households[i].town, townNames[0]) == 0)
            {
                bramptonPositiveCovidTestedCases += households[i].membersTestedPositive;
            }
            else if(strcmp(households[i].town, townNames[1]) == 0)
            {
                mississaugaPositiveCovidTestedCases += households[i].membersTestedPositive;
            }
            else if(strcmp(households[i].town, townNames[2]) == 0)
            {
                maplePositiveCovidTestedCases += households[i].membersTestedPositive;
            }
            else if(strcmp(households[i].town, townNames[3]) == 0)
            {
                vaughanPositiveCovidTestedCases += households[i].membersTestedPositive;
            }
            else if(strcmp(households[i].town, townNames[4]) == 0)
            {
                whitbyPositiveCovidTestedCases += households[i].membersTestedPositive;
            }
            else if(strcmp(households[i].town, townNames[5]) == 0)
            {
                oshawaPositiveCovidTestedCases += households[i].membersTestedPositive;
            }
        }

        TownRankingByCovidPositive townRankingByCovidPositive[6];

        strcpy(townRankingByCovidPositive[0].town, townNames[0]);
        townRankingByCovidPositive[0].membersTestedPositive = bramptonPositiveCovidTestedCases;

        strcpy(townRankingByCovidPositive[1].town, townNames[1]);
        townRankingByCovidPositive[1].membersTestedPositive = mississaugaPositiveCovidTestedCases;

        strcpy(townRankingByCovidPositive[2].town, townNames[2]);
        townRankingByCovidPositive[2].membersTestedPositive = maplePositiveCovidTestedCases;

        strcpy(townRankingByCovidPositive[3].town, townNames[3]);
        townRankingByCovidPositive[3].membersTestedPositive = vaughanPositiveCovidTestedCases;

        strcpy(townRankingByCovidPositive[4].town, townNames[4]);
        townRankingByCovidPositive[4].membersTestedPositive = whitbyPositiveCovidTestedCases;

        strcpy(townRankingByCovidPositive[5].town, townNames[5]);
        townRankingByCovidPositive[5].membersTestedPositive = oshawaPositiveCovidTestedCases;

        printf("%16s:%16s\n","Town","Covid Positive");
        for (int i = 0; i < 6; i++)
        {
            printf("%16s:%16d\n", townRankingByCovidPositive[i].town, townRankingByCovidPositive[i].membersTestedPositive);
        }
    }
}

void printRaceRankingByPoverty()
{
    int africanAmericanPovertyPercent = 0;
    int asianPovertyPercent = 0;
    int indigenousPovertyPercent = 0;
    int caucasianPovertyPercent = 0;
    int othersPovertyPercent = 0;

    int numOfAfricanAmerican = 0;
    int numOfAsian = 0;
    int numOfIndigenous = 0;
    int numOfCaucasian = 0;
    int numOfOthers = 0;

    int numOfAfricanAmericanPoverty = 0;
    int numOfAsianPoverty = 0;
    int numOfIndigenousPoverty = 0;
    int numOfCaucasianPoverty = 0;
    int numOfOthersPoverty = 0;

    for(int i=0; i<SIZE; i++)
    {
        if(strcmp(households[i].raceOfHeadOfHousehold, raceNames[0]) == 0)
        {
            numOfIndigenous++;
            if((households[i].numberOfPeople == 1 && households[i].yearlyIncome < 20000) || (households[i].numberOfPeople == 2 && households[i].yearlyIncome < 25000) || (households[i].numberOfPeople == 3 && households[i].yearlyIncome < 30000) || (households[i].numberOfPeople == 4 && households[i].yearlyIncome < 35000) || (households[i].numberOfPeople >= 5 && households[i].yearlyIncome < 40000))
            {
                numOfIndigenousPoverty++;
            }
        }
        else if(strcmp(households[i].raceOfHeadOfHousehold, raceNames[1]) == 0)
        {
            numOfCaucasian++;
            if((households[i].numberOfPeople == 1 && households[i].yearlyIncome < 20000) || (households[i].numberOfPeople == 2 && households[i].yearlyIncome < 25000) || (households[i].numberOfPeople == 3 && households[i].yearlyIncome < 30000) || (households[i].numberOfPeople == 4 && households[i].yearlyIncome < 35000) || (households[i].numberOfPeople >= 5 && households[i].yearlyIncome < 40000))
            {
                numOfCaucasianPoverty++;
            }
        }
        else if(strcmp(households[i].raceOfHeadOfHousehold, raceNames[2]) == 0)
        {
            numOfAfricanAmerican++;
            if((households[i].numberOfPeople == 1 && households[i].yearlyIncome < 20000) || (households[i].numberOfPeople == 2 && households[i].yearlyIncome < 25000) || (households[i].numberOfPeople == 3 && households[i].yearlyIncome < 30000) || (households[i].numberOfPeople == 4 && households[i].yearlyIncome < 35000) || (households[i].numberOfPeople >= 5 && households[i].yearlyIncome < 40000))
            {
                numOfAfricanAmericanPoverty++;
            }
        }
        else if(strcmp(households[i].raceOfHeadOfHousehold, raceNames[3]) == 0)
        {
            numOfAsian++;
            if((households[i].numberOfPeople == 1 && households[i].yearlyIncome < 20000) || (households[i].numberOfPeople == 2 && households[i].yearlyIncome < 25000) || (households[i].numberOfPeople == 3 && households[i].yearlyIncome < 30000) || (households[i].numberOfPeople == 4 && households[i].yearlyIncome < 35000) || (households[i].numberOfPeople >= 5 && households[i].yearlyIncome < 40000))
            {
                numOfAsianPoverty++;
            }
        }
        else
        {
            numOfOthers++;
            if((households[i].numberOfPeople == 1 && households[i].yearlyIncome < 20000) || (households[i].numberOfPeople == 2 && households[i].yearlyIncome < 25000) || (households[i].numberOfPeople == 3 && households[i].yearlyIncome < 30000) || (households[i].numberOfPeople == 4 && households[i].yearlyIncome < 35000) || (households[i].numberOfPeople >= 5 && households[i].yearlyIncome < 40000))
            {
                numOfOthersPoverty++;
            }
        }
    }

    indigenousPovertyPercent = (double)(numOfIndigenousPoverty / numOfIndigenous) * 100;
    caucasianPovertyPercent = (double)(numOfCaucasianPoverty / numOfCaucasian) * 100;
    africanAmericanPovertyPercent = (double)(numOfAfricanAmericanPoverty / numOfAfricanAmerican) * 100;
    asianPovertyPercent = (double)(numOfAsianPoverty / numOfAsian) * 100;
    othersPovertyPercent = (double)(numOfOthersPoverty / numOfOthers) * 100;

    RaceRankingByPoverty raceRankingByPoverty[5];

    strcpy(raceRankingByPoverty[0].race, raceNames[0]);
    raceRankingByPoverty[0].povertyPercent = indigenousPovertyPercent;

    strcpy(raceRankingByPoverty[1].race, raceNames[1]);
    raceRankingByPoverty[1].povertyPercent = caucasianPovertyPercent;

    strcpy(raceRankingByPoverty[2].race, raceNames[2]);
    raceRankingByPoverty[2].povertyPercent = africanAmericanPovertyPercent;

    strcpy(raceRankingByPoverty[3].race, raceNames[3]);
    raceRankingByPoverty[3].povertyPercent = asianPovertyPercent;

    strcpy(raceRankingByPoverty[4].race, raceNames[4]);
    raceRankingByPoverty[4].povertyPercent = othersPovertyPercent;

    printf("%22s:%35s\n","Races","Percent households below poverty line");
    for (int i = 0; i < 5; i++)
    {
        printf("%22s:%35d\n", raceRankingByPoverty[i].race, raceRankingByPoverty[i].povertyPercent);
    }
}