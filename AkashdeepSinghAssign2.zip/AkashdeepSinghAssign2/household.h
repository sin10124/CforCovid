//this is the header file
//Akashdeep Singh
//991586783
#define SIZE 100

typedef struct household {
    char region[50];
    char town[50];
    char raceOfHeadOfHousehold[50];
    int yearlyIncome;
    int numberOfPeople;
    int membersTested;
    int membersTestedPositive;
} Household;

Household households[SIZE];

typedef struct raceRankingByCovid {
    char race[50];
    int membersTested;
} RaceRankingByCovid;

typedef struct raceRankingByCovidPositive {
    char race[50];
    int membersTestedPositive;
} RaceRankingByCovidPositive;

typedef struct regionRankingByCovid {
    char region[50];
    int membersTested;
} RegionRankingByCovid;

typedef struct regionRankingByCovidPositive {
    char region[50];
    int membersTestedPositive;
} RegionRankingByCovidPositive;

typedef struct townRankingByCovid {
    char town[50];
    int membersTested;
} TownRankingByCovid;

typedef struct townRankingByCovidPositive {
    char town[50];
    int membersTestedPositive;
} TownRankingByCovidPositive;

typedef struct raceRankingByPoverty {
    char race[50];
    int povertyPercent;
} RaceRankingByPoverty;

char raceNames[5][20] = {"Indigenous","Caucasian","African American","Asian","Others"};
char regionNames[3][20] = {"Durham","Peel","York"};
char townForPeel[2][20] = {"Brampton","Mississauga"};
char townForYork[2][20] = {"Maple","Vaughan"};
char townForDurham[2][20] = {"Whitby","Oshawa"};

Household generateRandomHouseholds(Household households[SIZE], int start);
void printHouseholds();
void printMainMenu();
void printSubMenuForRaceTownAndRegion();
void printHouseholdsByRace();
void printHouseholdsByTown();
void printHouseholdsByRegion();
void printSubMenuForRaceRanking();
void printRaceRankingOfCovidTested();
void printRaceRankingOfCovidTestedPositive();
void printSubMenuForRegionRanking();
void printRegionRankingOfCovidTested();
void printRegionRankingOfCovidTestedPositive();
void printSubMenuForTownRanking();
void printTownRankingOfCovidTested();
void printTownRankingOfCovidTestedPositive();
void printRaceRankingByPoverty();